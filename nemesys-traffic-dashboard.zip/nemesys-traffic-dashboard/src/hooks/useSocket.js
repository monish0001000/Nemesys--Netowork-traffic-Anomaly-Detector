import { useEffect, useRef, useState, useCallback } from 'react'
import { createMockEngine } from '../lib/mockData'

// ─────────────────────────────────────────────────────────────────────────
// INTEGRATION POINT: flip this to false once the FastAPI backend (see PRD
// section 3.4) is running, and set VITE_WS_URL in .env. Nothing else in the
// component tree needs to change — every component below only reads state
// returned by this hook.
// ─────────────────────────────────────────────────────────────────────────
const USE_MOCK = true
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws/live'

const MAX_PACKETS = 120
const MAX_ANOMALIES = 60
const MAX_CHART_POINTS = 60

export function useSocket() {
  const [connectionStatus, setConnectionStatus] = useState('connecting') // connecting | live | reconnecting | offline
  const [metrics, setMetrics] = useState({ pps: 0, bps: 0, active_flows: 0, packets_total: 0 })
  const [chartData, setChartData] = useState([])
  const [packets, setPackets] = useState([])
  const [anomalies, setAnomalies] = useState([])
  const [protocolStats, setProtocolStats] = useState([])
  const [topTalkers, setTopTalkers] = useState([])
  const [status, setStatus] = useState({ capturing: false, interface: '—' })

  const cleanupRef = useRef(null)
  const wsRef = useRef(null)
  const retryRef = useRef(0)

  const handleMessage = useCallback((msg) => {
    switch (msg.type) {
      case 'metric_tick': {
        setMetrics(msg.payload)
        setChartData(prev => {
          const next = [...prev, {
            t: new Date(msg.payload.timestamp).toLocaleTimeString('en-GB'),
            pps: msg.payload.pps,
            bps: Math.round(msg.payload.bps / 1024)
          }]
          return next.slice(-MAX_CHART_POINTS)
        })
        break
      }
      case 'packet':
        setPackets(prev => [msg.payload, ...prev].slice(0, MAX_PACKETS))
        break
      case 'anomaly':
        setAnomalies(prev => [msg.payload, ...prev].slice(0, MAX_ANOMALIES))
        break
      case 'protocol_stats':
        setProtocolStats(msg.payload)
        break
      case 'top_talkers':
        setTopTalkers(msg.payload)
        break
      case 'status':
        setStatus(prev => ({ ...prev, ...msg.payload }))
        break
      default:
        break
    }
  }, [])

  useEffect(() => {
    if (USE_MOCK) {
      setConnectionStatus('live')
      cleanupRef.current = createMockEngine(handleMessage)
      return () => cleanupRef.current?.()
    }

    function connect() {
      setConnectionStatus(retryRef.current === 0 ? 'connecting' : 'reconnecting')
      const ws = new WebSocket(WS_URL)
      wsRef.current = ws

      ws.onopen = () => {
        retryRef.current = 0
        setConnectionStatus('live')
      }
      ws.onmessage = (evt) => {
        try {
          handleMessage(JSON.parse(evt.data))
        } catch (e) {
          console.error('Bad WS payload', e)
        }
      }
      ws.onclose = () => {
        setConnectionStatus('reconnecting')
        retryRef.current += 1
        const backoff = Math.min(1000 * 2 ** retryRef.current, 10000)
        setTimeout(connect, backoff)
      }
      ws.onerror = () => ws.close()
    }

    connect()
    return () => wsRef.current?.close()
  }, [handleMessage])

  return { connectionStatus, metrics, chartData, packets, anomalies, protocolStats, topTalkers, status }
}
